/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#000000",
        "on-primary": "#ffffff",
        secondary: "#40674d",
        sage: "#7FA88A",
        "sage-light": "#A8D5BA",
        peach: "#FFDAB9",
        background: "#f9f9f9",
        surface: "#ffffff",
        "surface-low": "#f4f3f3",
        "surface-high": "#e8e8e8",
        "on-surface": "#1a1c1c",
        "on-surface-variant": "#444748",
        outline: "#747878",
        "outline-variant": "#c4c7c7",
        error: "#ba1a1a",
        "error-container": "#ffdad6",
      },
      borderRadius: {
        card: "16px",
        input: "12px",
      },
      spacing: {
        "container-margin": "20px",
        xs: "4px",
        sm: "8px",
        md: "16px",
        lg: "24px",
        xl: "32px",
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [],
};
